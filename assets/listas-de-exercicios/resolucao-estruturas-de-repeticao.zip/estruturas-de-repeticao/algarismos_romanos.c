#include <stdio.h>

int main(void){
    int n,i;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        int num;
        int j;
        scanf("%d",&num);
        int m = num/1000;
        for(j=0;j<m;j++)
            printf("M");
        num = num-1000*m;
        if(num>=900){
            printf("CM");
            num -=900;
        }
        if(num>=500){
            printf("D");
            int c = (num-500)/100;
            for(j=0;j<c;j++){
                printf("C");
            }
            num -= 500+c*(100);
        }
        if(num>=400){
            printf("CD");
            num -= 400;
        }
        if(num>=100){
            int c = (num)/100;
            for(j=0;j<c;j++){
                printf("C");
            }
            num -= c*100;
        }
        if(num>=90){
            printf("XC");
            num-=90;
        }
        if(num>=50){
            int d = (num-50)/10;
            printf("L");
            for(j=0;j<d;j++)
                printf("X");
            num -= 50+d*10;
        }
        if(num>=40){
            printf("XL");
            num -= 40;

        }
        if(num>=10){
            int x = num/10;
            for(j=0;j<x;j++)
                printf("X");
            num -= x*10;
        }
        if(num>=9){
            printf("IX");
            num-=9;
        }
        if(num>=5){
            int u = (num-5);
            printf("V");
            for(j=0;j<u;j++)
                printf("I");
            num -= 5 + u;
        }
        if(num>=4){
            printf("IV");
            num -= 4;
        }
        if(num>0){
           int u = num;
            for(j=0;j<u;j++)
                printf("I");
            num -=u;
        } 
        printf("\n"); 
    }
    return 0;
}
