#include <stdio.h>

int main(void){
    float potencia,fatorial;
    float x;
    float soma;
    int i,sinal;
    scanf("%f",&x);
    potencia = x;
    fatorial = 1.0;
    soma = x;
    sinal = 1;
    for(i=1;i<=21;i+=2){
        potencia = potencia * x*x;
        fatorial = fatorial * (i+1)*(i+2);
        sinal = -sinal;
        soma = soma + sinal*potencia/fatorial;
    }
    printf("%f\n",soma);
    return 0;
}
