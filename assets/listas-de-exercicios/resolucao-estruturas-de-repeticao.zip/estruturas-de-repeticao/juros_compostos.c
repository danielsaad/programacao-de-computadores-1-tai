#include <stdio.h>

int main(void){
    float m;
    int n,i;
    float taxa;
    float juros = 1;
    scanf("%f %d %f",&m,&n,&taxa);
    float total = m;
    for(i=1;i<=n;i++){
        juros = juros * (1+taxa/100);
    }
    total = m*juros;
    printf("%f\n",total);
    return 0;
}
