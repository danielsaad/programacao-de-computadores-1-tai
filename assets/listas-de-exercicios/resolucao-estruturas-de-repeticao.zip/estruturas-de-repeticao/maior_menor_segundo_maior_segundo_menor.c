#include <stdio.h>

int main(void){
    int n;
    int i;
    int maior,menor,seg_maior,seg_menor;
    maior = -100001;
    seg_maior = -100001;
    menor = 100001;
    seg_menor = 100001;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        int x;
        scanf("%d",&x);
        if(x >= maior){
            seg_maior = maior;
            maior = x;
        }
        else if(x >= seg_maior){
            seg_maior = x;
        }

        if(x <= menor){
            seg_menor = menor;
            menor = x;
        }
        else if(x < seg_menor){
            seg_menor = x;
        }
    }
    printf("%d\n",maior);
    if(seg_maior != -100001){
        printf("%d\n",seg_maior);
    }
    else{
        printf("nao definido\n");
    }
    printf("%d\n",menor);
    if(seg_menor != 100001){
        printf("%d\n",seg_menor);
    }
    else{
        printf("nao definido\n");
    }
    return 0;
}
