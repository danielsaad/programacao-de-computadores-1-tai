#include <stdio.h>

int main(void){
    int n;
    int i,j;
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        int nro_asteriscos;
        if(i<=n/2 +1){
            nro_asteriscos = i;
        }
        else{
            nro_asteriscos = n-i+1;
        }
        for(j=0;j<nro_asteriscos;j++){
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
