#include <stdio.h>

int main(void){
    int i,j,n,k;
    char linha[82];

    scanf("%d %d",&n,&k);
    getchar();
    for(i=0;i<n;i++){
        fgets(linha,82,stdin);
        for(j=0;linha[j]!='\n';j++){
            int c = linha[j]+k;
            if(c>126){
                c-=95;
            }
            linha[j]=c;
        }
        printf("%s",linha);
    }
    return 0;
}


