#include <stdio.h>
#include <string.h>

int main(void) {
    int pos_atual = 0;
    int tam;
    char linha[1001];
    scanf("%s", linha);
    tam = strlen(linha);
    int op = 0;
    while (pos_atual < tam) {
        int i, j;
        int tam_casamento = 0;
        for (i = 0; i < pos_atual; i++) {
            int aux = 0;
            for (j = 0; pos_atual + j < tam && i + j < pos_atual; j++) {
                if (linha[i + j] == linha[pos_atual + j]){
                    aux++;
                }
                else{
                    break;
                }
            }
            if(tam_casamento < aux)
                tam_casamento = aux;
        }
        pos_atual += tam_casamento == 0 ? 1 : tam_casamento;
        op++;
    }
    printf("%d\n",op);
    return 0;
}