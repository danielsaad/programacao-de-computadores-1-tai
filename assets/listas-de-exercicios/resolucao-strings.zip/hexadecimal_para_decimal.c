#include <stdio.h>
#include <string.h>

int main (void) {
    char hexa[9];
    unsigned int decimal = 0;
    int i=0;
    scanf("%s", hexa);
    int tam = strlen(hexa);
    for(i=0; i < tam; i++) {
        decimal *= 16;
        if(hexa[i]>='0' && hexa[i]<='9'){
            decimal += (hexa[i]-'0');}
        else{
            decimal += (hexa[i]-'a'+10);
        }
    }
    printf("%u\n", decimal);
    return 0;
}