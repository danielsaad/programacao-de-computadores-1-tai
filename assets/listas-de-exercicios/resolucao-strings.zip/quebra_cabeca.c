#include <stdio.h>
#include <string.h>

int main() {
    int letras[128];
    int i;
    for (i = 0; i < 128; i++)
        letras[i] = 0;
    char str[100001];
    scanf("%s", str);
    int tam = strlen(str);
    for (i = 0; i < tam; i++) {
        letras[str[i]]++;
    }
    int num_impar = 0;
    for (i = 0; i < 128; i++) {
        if (letras[i] % 2 == 1) {
            num_impar++;
        }
    }
    if (num_impar > 1) {
        printf("Nao\n");
    } else {
        printf("Sim\n");
    }
    return 0;
}
