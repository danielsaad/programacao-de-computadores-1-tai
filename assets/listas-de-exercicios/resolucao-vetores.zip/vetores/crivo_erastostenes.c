#include <stdio.h>
#include <math.h>

int primo[10000001];

int main(void){
    int i,n,num;
    for(i=0;i<=10000000;i++){
        primo[i] = 1;
    }
    primo[0] = 0;
    primo[1] = 0;
    for(num=2;num<=sqrt(10000000);num++){
        if(primo[num]){
            int j;
            for(j=num*2;j<=10000000;j+=num){
                primo[j] = 0;
            }
        }
    }
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&num);
        primo[num]==1 ? printf("primo\n") : printf("composto\n");
    }
    return 0;
}
