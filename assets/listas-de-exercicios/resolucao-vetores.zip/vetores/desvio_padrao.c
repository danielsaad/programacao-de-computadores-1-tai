#include <stdio.h>
#include <math.h>

int main(void){
    int i,n;
    float media=0,variancia=0,desvio_padrao;
    scanf("%d",&n);
    float notas[n];
    for(i=0;i<n;i++){
        scanf("%f",&notas[i]);
    }
    for(i=0;i<n;i++){
        media += notas[i];
    }
    media /= n;
    for(i=0;i<n;i++){
        variancia += pow(notas[i]-media,2);
    }
    variancia /= n;
    desvio_padrao = sqrt(variancia);
    printf("%f\n",desvio_padrao);
    return 0;
}
